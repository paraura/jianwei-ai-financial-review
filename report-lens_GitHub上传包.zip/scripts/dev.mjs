import http from 'node:http';
import worker from '../worker/index.js';
const port=Number(process.env.PORT||4173);
http.createServer(async(req,res)=>{try{let body='';for await(const chunk of req)body+=chunk;const request=new Request('http://localhost:'+port+req.url,{method:req.method,headers:req.headers,...(['GET','HEAD'].includes(req.method)?{}:{body})});const response=await worker.fetch(request,process.env);res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));}catch{res.writeHead(500);res.end('Server error');}}).listen(port,'127.0.0.1',()=>console.log('Local: http://localhost:'+port));
